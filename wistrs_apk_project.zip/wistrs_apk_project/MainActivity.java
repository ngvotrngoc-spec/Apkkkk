package com.wistrs.hub;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    // Thay GIST_ID và TOKEN của bạn vào đây nếu cần gọi API trực tiếp
    private static final String GIST_ID = "98d4c7377a004199e54cccf5a5e683bf";
    private static final String FILE_NAME = "wistrs_db.json";
    private static final String GITHUB_TOKEN = "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";

    private EditText editSearch;
    private ListView listView;
    private TextView txtNotice;

    private final List<HashMap<String, String>> allGames = new ArrayList<>();
    private final List<HashMap<String, String>> filteredGames = new ArrayList<>();
    private GameAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNotice = findViewById(R.id.txt_notice);
        editSearch = findViewById(R.id.edit_search);
        listView = findViewById(R.id.listview1);

        adapter = new GameAdapter();
        listView.setAdapter(adapter);

        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterGames(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= filteredGames.size()) return;
                String link = filteredGames.get(position).get("link");
                if (link == null || link.trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Game chưa có link tải", Toast.LENGTH_SHORT).show();
                    return;
                }
                String url = link.trim();
                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    url = "https://" + url;
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Không mở được liên kết", Toast.LENGTH_SHORT).show();
                }
            }
        });

        fetchGistData();
    }

    private void fetchGistData() {
        txtNotice.setText("Đang tải dữ liệu từ Gist...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL("https://api.github.com/gists/" + GIST_ID);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(15000);
                    conn.setRequestProperty("Accept", "application/vnd.github+json");
                    if (!GITHUB_TOKEN.trim().isEmpty()) {
                        conn.setRequestProperty("Authorization", "Bearer " + GITHUB_TOKEN.trim());
                    }

                    int code = conn.getResponseCode();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(
                            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(),
                            "UTF-8"
                    ));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                    reader.close();

                    if (code < 200 || code >= 300) {
                        throw new Exception("HTTP " + code);
                    }

                    JSONObject root = new JSONObject(sb.toString());
                    JSONObject files = root.optJSONObject("files");
                    if (files == null || !files.has(FILE_NAME)) {
                        throw new Exception("Không tìm thấy " + FILE_NAME);
                    }

                    String rawContent = files.optJSONObject(FILE_NAME).optString("content", "{}");
                    parseDatabase(rawContent);
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            txtNotice.setText("Lỗi tải Gist: " + e.getMessage());
                        }
                    });
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }

    private void parseDatabase(String rawJson) throws Exception {
        JSONObject db = new JSONObject(rawJson);
        JSONObject noticeObj = db.optJSONObject("notice");
        final String noticeText = noticeObj != null ? noticeObj.optString("content", "").trim() : "";

        JSONObject deleted = db.optJSONObject("deletedGames");
        if (deleted == null) deleted = new JSONObject();

        JSONObject overrides = db.optJSONObject("gameOverrides");
        if (overrides == null) overrides = new JSONObject();

        JSONArray added = db.optJSONArray("addedGames");
        if (added == null) added = new JSONArray();

        LinkedHashMap<String, HashMap<String, String>> map = new LinkedHashMap<>();

        for (int i = 0; i < added.length(); i++) {
            JSONObject g = added.optJSONObject(i);
            if (g == null) continue;
            String id = String.valueOf(g.opt("id")).trim();
            if (id.isEmpty() || "null".equals(id) || deleted.optBoolean(id, false)) continue;

            String name = g.optString("name", "").trim();
            String link = g.optString("link", "").trim();
            if (link.isEmpty() && g.has("links")) {
                JSONArray arr = g.optJSONArray("links");
                if (arr != null && arr.length() > 0) link = arr.optString(0, "").trim();
            }
            if (name.isEmpty() || link.isEmpty()) continue;

            HashMap<String, String> row = new HashMap<>();
            row.put("id", id);
            row.put("name", name);
            row.put("size", g.optString("size", "").trim());
            row.put("type", g.optString("adminType", "original").trim());
            row.put("note", g.optString("note", "").trim());
            row.put("link", link);
            map.put(id, row);
        }

        Iterator<String> keys = overrides.keys();
        while (keys.hasNext()) {
            String id = keys.next().trim();
            if (deleted.optBoolean(id, false)) {
                map.remove(id);
                continue;
            }
            JSONObject g = overrides.optJSONObject(id);
            if (g == null) continue;

            HashMap<String, String> row = map.containsKey(id) ? map.get(id) : new HashMap<String, String>();
            String name = g.optString("name", row.containsKey("name") ? row.get("name") : "").trim();
            String link = g.optString("link", row.containsKey("link") ? row.get("link") : "").trim();
            if (link.isEmpty() && g.has("links")) {
                JSONArray arr = g.optJSONArray("links");
                if (arr != null && arr.length() > 0) link = arr.optString(0, "").trim();
            }
            if (name.isEmpty() || link.isEmpty()) {
                map.remove(id);
                continue;
            }

            row.put("id", id);
            row.put("name", name);
            row.put("size", g.optString("size", row.containsKey("size") ? row.get("size") : "").trim());
            row.put("type", g.optString("adminType", row.containsKey("type") ? row.get("type") : "original").trim());
            row.put("note", g.optString("note", row.containsKey("note") ? row.get("note") : "").trim());
            row.put("link", link);
            map.put(id, row);
        }

        final List<HashMap<String, String>> ordered = new ArrayList<>(map.values());
        Collections.reverse(ordered);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                txtNotice.setText(noticeText.isEmpty() ? "Sẵn sàng (" + ordered.size() + " game)" : noticeText);
                allGames.clear();
                allGames.addAll(ordered);
                filterGames(editSearch.getText().toString());
            }
        });
    }

    private void filterGames(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        filteredGames.clear();
        for (HashMap<String, String> item : allGames) {
            String name = item.get("name") != null ? item.get("name").toLowerCase(Locale.ROOT) : "";
            String note = item.get("note") != null ? item.get("note").toLowerCase(Locale.ROOT) : "";
            if (q.isEmpty() || name.contains(q) || note.contains(q)) {
                filteredGames.add(item);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private class GameAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return filteredGames.size();
        }

        @Override
        public Object getItem(int position) {
            return filteredGames.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                v = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_game, parent, false);
            }

            TextView txtName = v.findViewById(R.id.txt_name);
            TextView txtMeta = v.findViewById(R.id.txt_meta);
            TextView txtNote = v.findViewById(R.id.txt_note);

            HashMap<String, String> item = filteredGames.get(position);
            String name = item.get("name");
            String type = item.get("type");
            String size = item.get("size");
            String note = item.get("note");

            txtName.setText(name);
            txtMeta.setText(type + (size != null && !size.isEmpty() ? " · " + size : ""));

            if (note != null && !note.isEmpty()) {
                txtNote.setVisibility(View.VISIBLE);
                txtNote.setText(note);
            } else {
                txtNote.setVisibility(View.GONE);
            }

            return v;
        }
    }
}
