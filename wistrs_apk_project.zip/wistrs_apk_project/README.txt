BỘ FILE DỰ ÁN APP APK WISTRSHUB
================================

1. MainActivity.java
   - Mở file, sửa dòng:
     private static final String GIST_ID = "GIST_ID_CUA_BAN";
   - Tự động gọi GitHub Gist API, đọc thông báo (notice), gộp addedGames + gameOverrides, loại bỏ deletedGames, hỗ trợ tìm kiếm và bấm để mở link tải.

2. res/layout/activity_main.xml & res/layout/item_game.xml
   - Giao diện tối gọn nhẹ, không hiệu ứng làm lag máy.

3. cleaned_games.json
   - Danh sách game đã được gộp & lọc sạch sẵn từ wistrs_db.txt của bạn.
